package io.mycat.ringbuffer;

import sun.misc.Unsafe;

/**
 * Created by 01119371 on 2016/8/29.
 */

public class Sequence extends RhsPadding {
    static final long INITIAL_VALUE = -1L;
    private static final Unsafe UNSAFE = MemoryMappedUtils.getUnsafe();
    private static final long VALUE_OFFSET;

    public Sequence() {
        this(-1L);
    }

    public Sequence(long initialValue) {
        UNSAFE.putOrderedLong(this, VALUE_OFFSET, initialValue);
    }

    public long get() {
        return this.index;
    }

    public void set(long value) {
        UNSAFE.putOrderedLong(this, VALUE_OFFSET, value);
    }

    public void setVolatile(long value) {
        UNSAFE.putLongVolatile(this, VALUE_OFFSET, value);
    }

    public boolean compareAndSet(long expectedValue, long newValue) {
        return UNSAFE.compareAndSwapLong(this, VALUE_OFFSET, expectedValue, newValue);
    }

    public long incrementAndGet() {
        return this.addAndGet(1L);
    }

    public long addAndGet(long increment) {
        long currentValue;
        long newValue;
        do {
            currentValue = this.get();
            newValue = currentValue + increment;
        } while(!this.compareAndSet(currentValue,newValue));
        return newValue;
    }

    public String toString() {
        return Long.toString(this.get());
    }

    static {
        try {
            VALUE_OFFSET = UNSAFE.objectFieldOffset(Index.class.getDeclaredField("index"));
        } catch (Exception var1) {
            throw new RuntimeException(var1);
        }
    }
}