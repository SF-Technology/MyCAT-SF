package io.mycat.utils

import io.mycat.rpc.{RpcAddress, RpcEndpointRef, RpcEnv, RpcTimeout}

import scala.language.postfixOps

private[mycat] object RpcUtils {

  /**
   * Retrieve a [[io.mycat.rpc.RpcEndpointRef]] which is located in the driver via its name.
   */
  def makeDriverRef(name: String, conf: MycatConf, rpcEnv: RpcEnv): RpcEndpointRef = {
    val driverHost: String = conf.get("mycat.driver.host", "localhost")
    val driverPort: Int = conf.getInt("mycat.driver.port", 7077)
    Utils.checkHost(driverHost, "Expected hostname")
    rpcEnv.setupEndpointRef(RpcAddress(driverHost, driverPort), name)
  }

  /** Returns the configured number of times to retry connecting */
  def numRetries(conf: MycatConf): Int = {
    conf.getInt("mycat.rpc.numRetries", 3)
  }

  /** Returns the configured number of milliseconds to wait on each retry */
  def retryWaitMs(conf: MycatConf): Long = {
    conf.getTimeAsMs("mycat.rpc.retry.wait", "3s")
  }

  /** Returns the default Mycat timeout to use for RPC ask operations. */
  def askRpcTimeout(conf: MycatConf): RpcTimeout = {
    RpcTimeout(conf, Seq("mycat.rpc.askTimeout", "mycat.network.timeout"), "120s")
  }

  /** Returns the default Mycat timeout to use for RPC remote endpoint lookup. */
  def lookupRpcTimeout(conf: MycatConf): RpcTimeout = {
    RpcTimeout(conf, Seq("mycat.rpc.lookupTimeout", "mycat.network.timeout"), "120s")
  }

  private val MAX_MESSAGE_SIZE_IN_MB = Int.MaxValue / 1024 / 1024

  /** Returns the configured max message size for messages in bytes. */
  def maxMessageSizeBytes(conf: MycatConf): Int = {
    val maxSizeInMB = conf.getInt("mycat.rpc.message.maxSize", 128)
    if (maxSizeInMB > MAX_MESSAGE_SIZE_IN_MB) {
      throw new IllegalArgumentException(
        s"mycat.rpc.message.maxSize should not be greater than $MAX_MESSAGE_SIZE_IN_MB MB")
    }
    maxSizeInMB * 1024 * 1024
  }
}
