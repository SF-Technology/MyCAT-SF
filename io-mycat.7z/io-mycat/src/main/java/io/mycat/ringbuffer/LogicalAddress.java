package io.mycat.ringbuffer;

import sun.misc.Unsafe;

import static io.mycat.ringbuffer.MemoryMappedUtils.BYTE_ARRAY_OFFSET;

/**
 * 通过LogicalAddress访问数据
 *
 * @author zagnix
 * @version 1.0
 * @create 2016-09-07 10:00
 */
public abstract class LogicalAddress {

    /**
     * offset
     */
    protected long start = 0;

    /**
     * Block size is OS'pageSize of power 2
     */
    protected long size = 0;

    /**
     * Block Address
     */
    protected long address = 0L;

    /**
     * Fqueue Block(file block ro momery block) index
     */
    protected int blockid = 0;

    /**
     * Unsafe
     */
    protected final Unsafe UNSAFE;



    /**
     * Limits the number of bytes to copy per {@link Unsafe#copyMemory(long, long, long)} to
     * allow safepoint polling during a large copy.
     */
    private static final long UNSAFE_COPY_THRESHOLD = 1024L * 1024L;

    public LogicalAddress(){
        UNSAFE = MemoryMappedUtils.getUnsafe();
    }

    /**
     * Reads a byte from the specified position.
     * @param pos the position in the memory mapped file
     * @return the value read
     */
    protected byte getByte(long pos) {
        return UNSAFE.getByte(this.address + pos);
    }

    /**
     * Reads a byte (volatile) from the specified position.
     * @param pos the position in the memory mapped file
     * @return the value read
     */
    protected byte getByteVolatile(long pos) {
        return UNSAFE.getByteVolatile(null, this.address + pos);
    }

    /**
     * Read a int form the specified position
     * @param pos  the position int the memory mapped file
     * @return the value read
     */
    protected int getInt(long pos){
        return UNSAFE.getInt(this.address + pos);
    }


    /**
     * Read a int(volatile) form the specified position
     * @param pos the position int the memory mapped file
     * @return the value read
     */

    protected int getIntVolatile(long pos){
        return UNSAFE.getIntVolatile(null,this.address + pos);
    }

    /**
     * Read a long form the specified position
     * @param pos the position int the memory mapped file
     * @return the value read
     */

    protected long getLong(long pos){
        return UNSAFE.getLong(this.address + pos);
    }


    /**
     * Read a long (volatile) form the specified position
     * @param pos the position int the memory mapped file
     * @return the value read
     */

    protected long getVolatileLong(long pos){
        return UNSAFE.getLongVolatile(null,this.address + pos);
    }


    /**
     * Writes a byte to the specified position.
     * @param pos the position in the memory mapped file
     * @param val the value to write
     */
    public void putByte(long pos, byte val) {
        UNSAFE.putByte(this.address + pos, val);
    }

    /**
     * Writes a byte (volatile) to the specified position.
     * @param pos the position in the memory mapped file
     * @param val the value to write
     */
    protected void putByteVolatile(long pos, byte val) {
        UNSAFE.putByteVolatile(null, this.address + pos, val);
    }

    /**
     * Writes an int to the specified position.
     * @param pos the position in the memory mapped file
     * @param val the value to write
     */
    public void putInt(long pos, int val) {
        UNSAFE.putInt(this.address + pos, val);
    }

    /**
     * Writes an int (volatile) to the specified position.
     * @param pos the position in the memory mapped file
     * @param val the value to write
     */
    protected void putIntVolatile(long pos, int val) {
        UNSAFE.putIntVolatile(null, this.address + pos, val);
    }

    /**
     * Writes a long to the specified position.
     * @param pos the position in the memory mapped file
     * @param val the value to write
     */
    public void putLong(long pos, long val) {
        UNSAFE.putLong(this.address + pos, val);
    }

    /**
     * Writes a long (volatile) to the specified position.
     * @param pos the position in the memory mapped file
     * @param val the value to write
     */
    protected void putLongVolatile(long pos, long val) {
        UNSAFE.putLongVolatile(null, this.address + pos, val);
    }

    /**
     * Copy src data  to des
     *
     * @param src
     * @param srcOffset
     * @param dst
     * @param dstOffset
     * @param length
     */
    private  void copyMemory(
            Object src, long srcOffset, Object dst, long dstOffset, long length) {
        // Check if dstOffset is before or after srcOffset to determine if we should copy
        // forward or backwards. This is necessary in case src and dst overlap.
        if (dstOffset < srcOffset) {
            while (length > 0) {
                long size = Math.min(length, UNSAFE_COPY_THRESHOLD);
                UNSAFE.copyMemory(src, srcOffset, dst, dstOffset, size);
                length -= size;
                srcOffset += size;
                dstOffset += size;
            }
        } else {
            srcOffset += length;
            dstOffset += length;
            while (length > 0) {
                long size = Math.min(length, UNSAFE_COPY_THRESHOLD);
                srcOffset -= size;
                dstOffset -= size;
                UNSAFE.copyMemory(src,srcOffset, dst, dstOffset, size);
                length -= size;
            }

        }
    }


    /**
     * Reads a buffer of data.
     * @param pos the position in the memory mapped file
     * @param data the input buffer
     * @param offset the offset in the buffer of the first byte to read data into
     * @param length the length of the data
     */
    public void getBytes(long pos, byte[] data, int offset, int length) {
       copyMemory(null, this.address + pos, data, BYTE_ARRAY_OFFSET + offset, length);
    }

    /**
     * Writes a buffer of data.
     * @param pos the position in the memory mapped file
     * @param data the output buffer
     * @param offset the offset in the buffer of the first byte to write
     * @param length the length of the data
     */
    public void setBytes(long pos, byte[] data, int offset, int length) {
        copyMemory(data, BYTE_ARRAY_OFFSET + offset, null, this.address + pos, length);
    }


    /**
     *
     * @param pos
     * @param expected
     * @param value
     * @return
     */

    protected boolean compareAndSwapInt(long pos, int expected, int value) {
        return UNSAFE.compareAndSwapInt(null, this.address + pos, expected, value);
    }

    /**
     *
     * @param pos
     * @param expected
     * @param value
     * @return
     */

    protected boolean compareAndSwapLong(long pos, long expected, long value) {
        return UNSAFE.compareAndSwapLong(null, this.address + pos, expected, value);
    }

    /**
     *
     * @param pos
     * @param delta
     * @return
     */
    protected long getAndAddLong(long pos, long delta) {
        return UNSAFE.getAndAddLong(null, this.address + pos, delta);
    }

    protected abstract long getOsPageSzie();


    public long getStart() {
        return start;
    }

    public void setStart(long start) {
        this.start = start;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public long getAddress() {
        return address;
    }

    public void setAddress(long address) {
        this.address = address;
    }

    public int getBlockid() {
        return blockid;
    }

    public void setBlockid(int blockid) {
        this.blockid = blockid;
    }
}
