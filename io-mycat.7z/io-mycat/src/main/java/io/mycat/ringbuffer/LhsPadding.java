package io.mycat.ringbuffer;

/**
 * Created by 01119371 on 2016/8/29.
 */
public class LhsPadding {
    protected long p1;
    protected long p2;
    protected long p3;
    protected long p4;
    protected long p5;
    protected long p6;
    protected long p7;
    LhsPadding() {
    }
}
