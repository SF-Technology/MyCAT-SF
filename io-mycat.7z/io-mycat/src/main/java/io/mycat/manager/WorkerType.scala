package io.mycat.manager

/**
  * Created by 01119371 on 2016/8/18.
  */
private[mycat] object WorkerType extends Enumeration {
  type WorkerType = Value
  val AGENT, WEBUI, MYCATSERVER, UNKNOWN = Value
}