
package io.mycat.ringbuffer;

/**
 *       Index File structure
 *        _______________________________
 *       | Magic Number 4 byte          |
 *       |______________________________|
 *       | current write index 8 byte   |
 *       |______________________________|
 *       | current read index 8 byte    |
 *       |______________________________|
 *       |  index address  8 byte       |
 *       |______________________________|
 *
 *       Index Address Structure
 *       Status Flags
 *       b0  : commit;
 *       b1  : rollback;
 *       b2 ~ b50  file offset;
 *       b51 ~ b63 file id;
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */


