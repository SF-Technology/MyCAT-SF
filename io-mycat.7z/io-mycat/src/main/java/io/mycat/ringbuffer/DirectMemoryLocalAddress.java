package io.mycat.ringbuffer;

/**
 * 数据存储在off-heap中
 *
 * @author zagnix
 * @version 1.0
 * @create 2016-09-07 10:01
 */

public class DirectMemoryLocalAddress extends LogicalAddress {
    @Override
    protected long getOsPageSzie() {
        return 0;
    }
}
