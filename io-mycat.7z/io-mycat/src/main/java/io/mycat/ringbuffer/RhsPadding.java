package io.mycat.ringbuffer;

/**
 * Created by 01119371 on 2016/8/29.
 */
public class RhsPadding extends Index {
    protected long p9;
    protected long p10;
    protected long p11;
    protected long p12;
    protected long p13;
    protected long p14;
    protected long p15;

    RhsPadding() {
    }
}
