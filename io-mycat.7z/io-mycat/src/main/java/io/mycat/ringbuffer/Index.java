package io.mycat.ringbuffer;

/**
 * Created by 01119371 on 2016/8/29.
 */

public class Index {
    protected volatile long index;
    Index() {
    }
}
