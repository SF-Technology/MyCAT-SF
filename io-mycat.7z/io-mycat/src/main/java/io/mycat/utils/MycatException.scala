package io.mycat.utils

/**
  * Created by 01119371 on 2016/8/18.
  */
class MycatException(message: String, cause: Throwable)
  extends Exception(message, cause) {

  def this(message: String) = this(message, null)
}
