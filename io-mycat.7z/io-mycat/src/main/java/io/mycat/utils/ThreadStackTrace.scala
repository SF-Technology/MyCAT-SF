package io.mycat.utils

/**
 * Used for shipping per-thread stacktraces from the executors to driver.
 */
private[mycat] case class ThreadStackTrace(
  threadId: Long,
  threadName: String,
  threadState: Thread.State,
  stackTrace: String)
