/**
 * Mappedbus is a Java based high throughput, low latency message bus, using either a memory mapped file or shared memory as transport
 *
 */
package io.mycat.mappedbus;