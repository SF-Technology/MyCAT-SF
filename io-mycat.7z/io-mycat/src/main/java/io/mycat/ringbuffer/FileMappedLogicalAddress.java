package io.mycat.ringbuffer;

import sun.misc.Unsafe;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;

/**
 * Created by 01119371 on 2016/9/1.
 */
public final class FileMappedLogicalAddress extends LogicalAddress {
    /**
     * 每个文件对应一个
     * 记录文件路径
     * 映射的逻辑地址
     * 文件大小必须是文件系统页的整数倍
     * 常用操作get/set
     */
    private final String path;

    public FileMappedLogicalAddress(int fileid,String path,long size){
        super();
        this.path = path;
        this.size = (size);
        this.blockid = fileid;
        init();
    }

    private void init() {
        try {
            final RandomAccessFile backingFile = new RandomAccessFile(this.path, "rw");
            final FileChannel ch = backingFile.getChannel();
            this.address = MemoryMappedUtils.map(ch,MemoryMappedUtils.MAP_RW,0L,this.size);
            ch.close();
            backingFile.close();
        } catch (Exception e) {
            e.printStackTrace();
            MemoryMappedUtils.unmap(this.address,this.size);
        }
    }

    /**
     * Get OS Page Size
     *
     * @return
     */
    @Override
    protected long getOsPageSzie() {
        return Unsafe.getUnsafe().pageSize();
    }

    /**
     * OS Page Size
     * @param i
     * @return
     */
    private  long roundToOsPageSzie(long i) {
        return (i + getOsPageSzie()) & ~getOsPageSzie();
    }


    /**
     * Closes the writer.
     *
     * @throws IOException if there was an error closing the file
     */
    public void close() throws IOException {
        try {
            MemoryMappedUtils.unmap(this.address,this.size);
        } catch(Exception e) {
            throw new IOException("Unable to close the file", e);
        }
    }

}
