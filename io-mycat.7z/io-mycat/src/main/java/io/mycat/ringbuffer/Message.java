package io.mycat.ringbuffer;

/**
 * Message Base Class
 *
 * @author zagnix
 * @version 1.0
 * @create 2016-09-07 16:34
 */

public class Message {
}
