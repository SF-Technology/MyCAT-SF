package io.mycat.ringbuffer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.misc.Unsafe;
import sun.nio.ch.FileChannelImpl;

import java.io.FileDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.MappedByteBuffer;
import java.nio.channels.Channel;
import java.nio.channels.FileChannel;


/**
 * Created by 01119371 on 2016/9/1.
 */

@SuppressWarnings("restriction")
public final class MemoryMappedUtils {

    private final static Logger logger = LoggerFactory.getLogger(MemoryMappedUtils.class);

    private static final Unsafe _UNSAFE;
    private static final Method _MAP;
    private static final Method _UNMAP;
    private static final Method _ISLOADED0;

    private static final Method _LOAD0;
    private static final Method _FORCE0;

    public static final int MAP_RO = 0;
    public static final int MAP_RW = 1;
    public static final int MAP_PV = 2;


    public static final int BYTE_ARRAY_OFFSET;

    static {
        Unsafe unsafe;
        Method mmap;
        Method ummap;
        Method lsloaded0;
        Method load0;
        Method force0;
        try {
            /**
             * Unsafe class reflect the variable of the theUnSafe。
             */
            Field theUnsafeField = Unsafe.class.getDeclaredField("theUnsafe");
            theUnsafeField.setAccessible(true);
            unsafe = (Unsafe) theUnsafeField.get(null);


            /**
             * FileChannelImpl class reflect the methods of these mmap/ummap
             */
            mmap = FileChannelImpl.class.getDeclaredMethod("map0",int.class,long.class,long.class);
            mmap.setAccessible(true);

            ummap = FileChannelImpl.class.getDeclaredMethod("unmap0",long.class,long.class);
            ummap.setAccessible(true);


            /**
             * MappedByteBuffer class reflect the methods of these isLoad0 load0,force0
             */
            lsloaded0 = MappedByteBuffer.class.getDeclaredMethod("isLoaded0", long.class, long.class, int.class);
            lsloaded0.setAccessible(true);

            load0 = MappedByteBuffer.class.getDeclaredMethod("load0", long.class, long.class);
            load0.setAccessible(true);

            force0 = MappedByteBuffer.class.getDeclaredMethod("force0", FileDescriptor.class, long.class, long.class);
            force0.setAccessible(true);

        } catch (Exception e) {
           logger.error(e.getMessage());
            unsafe = null;
            mmap = null;
            ummap = null;
            lsloaded0 = null;
            load0 = null;
            force0 = null;
        }

        _UNSAFE = unsafe;
        _MAP = mmap;
        _UNMAP = ummap;
        _ISLOADED0 = lsloaded0;
        _LOAD0 = load0;
        _FORCE0 = force0;

        if (_UNSAFE != null) {
            BYTE_ARRAY_OFFSET = _UNSAFE.arrayBaseOffset(byte[].class);
        } else {
            BYTE_ARRAY_OFFSET = 0;
        }
    }


    public static Unsafe getUnsafe() {
        return _UNSAFE;
    }

    public static long map(FileChannel ch, int mode, long start, long size) throws Exception {
        return (Long) _UNMAP.invoke(ch, mode, start, size);
    }

    public static void unmap(long start,long size)  {
        try {
            _UNMAP.invoke(null,start,size);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    public static boolean Isloaded0() {
        return true;
    }

    public static void getLoad0() {

    }

    public static void getForce0() {

    }

    /**
     * OS Page Size
     * @param i
     * @return
     */
    public static long roundToOsPageSzie(long i) {
        long pagesize = Unsafe.getUnsafe().pageSize();
        return (i + pagesize) & ~pagesize;
    }



}
