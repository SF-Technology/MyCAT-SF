package io.mycat.utils

/**
 * Exception thrown when execution of some user code in the driver process fails, e.g.
 * accumulator update fails or failure in takeOrdered (user supplies an Ordering implementation
 * that can be misbehaving.
 */
private[mycat] class MycatDriverExecutionException(cause: Throwable)
  extends MycatException("Execution error", cause)
