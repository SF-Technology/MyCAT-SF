package io.mycat.ringbuffer;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Created by 01119371 on 2016/9/1.
 */
public class FileMappedManager {

    /**
     * 管理索引文件与具体文件对应的关系
     * 索引文件可以位于内存中或者文件中。
     */
    /**
     * fileid ->>FileMappedLogicalAddress
     */
    private ConcurrentHashMap<String,FileMappedLogicalAddress> flieIndexMap =
        new ConcurrentHashMap<String,FileMappedLogicalAddress>(8192);
    private final FileMappedLogicalAddress fileIndexRingQueue;
    private FileMappedLogicalAddress currentileMapped = null;
    private AtomicLong fileId = new AtomicLong(1) ;
    private final long fileQueueSize;

    public FileMappedManager(long fileQueueSize){
        this.fileQueueSize = MemoryMappedUtils.roundToOsPageSzie(fileQueueSize);
        this.fileIndexRingQueue =
                new FileMappedLogicalAddress((int)fileId.get(),"./indexfilequeue.ring",1024*1024*512L);
        int fileid = (int) fileId.getAndIncrement();
        this.currentileMapped =
                new FileMappedLogicalAddress(fileid,"./filequeue.ring" + fileid,1024*1024*256L);
        flieIndexMap.put(String.valueOf(fileid),currentileMapped);
    }


    public ConcurrentHashMap<String, FileMappedLogicalAddress> getFlieIndexMap() {
        return flieIndexMap;
    }

    public void setFlieIndexMap(ConcurrentHashMap<String, FileMappedLogicalAddress> flieIndexMap) {
        this.flieIndexMap = flieIndexMap;
    }

    /**
     * 将一个消息放到
     * @param message
     * @return
     */
    public boolean offer(Message message){

        return true;
    }

    /**
     * 获取一个消息
     * @return
     */
    public Message poll(){
        Message message = null;

        return message;
    }

    public long allocAddress(){
        //long address = currentileMapped.getAndAddLong()

        return 0L;
    }





}
