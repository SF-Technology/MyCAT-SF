package io.mycat.ringbuffer;

import java.util.AbstractQueue;
import java.util.Iterator;

/**
 * Created by 01119371 on 2016/9/1.
 */
public class FRingQueue<T> extends AbstractQueue<T> {

    /**
     * 提供Ring队列的读写操作
     * 顺序读写
     * 数据必须满足8字节对齐
     */

    private final FileMappedManager fileMappedManager;

    public FRingQueue(FileMappedManager fileMappedManager){
        this.fileMappedManager = fileMappedManager;
    }

    @Override
    public Iterator<T> iterator() {
        return null;
    }

    @Override
    public int size() {
        return 0;
    }

    @Override
    public boolean offer(T message) {
        return false;
    }

    @Override
    public T poll() {

        return null;
    }

    @Override
    public T peek() {
        return null;
    }

}
