package io.mycat.utils

/**
  * Created by 01119371 on 2016/8/18.
  */
private class MycatShutdownHook(private val priority: Int, hook: () => Unit)
  extends Comparable[MycatShutdownHook] {

  override def compareTo(other: MycatShutdownHook): Int = {
    other.priority - priority
  }

  def run(): Unit = hook()

}
