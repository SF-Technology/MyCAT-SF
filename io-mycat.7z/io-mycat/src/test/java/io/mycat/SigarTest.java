package io.mycat;

//import org.hyperic.sigar.*;

public class SigarTest {


	public static void main(String[] args) {
		
//		Sigar sigar = new Sigar();
//		try{
//		  Mem mem = sigar.getMem();
//		  CpuPerc cpuCerc = sigar.getCpuPerc();Swap swap = sigar.getSwap();
//
//		}catch (Exception e) {
//			e.printStackTrace();
//		}
    }

}
